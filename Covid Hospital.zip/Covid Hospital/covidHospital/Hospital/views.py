from django.shortcuts import render
from django.http import HttpResponse
from Hospital.models import Hospital
from Hospital.models import Patient
from Hospital.models import Doctor
from Hospital.models import Appointment
from Hospital.models import Vaccine
from Hospital.models import Bed
from Hospital.models import vaccine_in_hosp
from Hospital.models import book_vaccine


# Create your views here.
def home(request):
    beds= Bed.objects.filter(available=True)
    vaccines=Vaccine.objects.all()
    Hosp_vax=vaccine_in_hosp.objects.all()
    sum=0
    for hosp in Hosp_vax:
        sum+=hosp.available_in_stock
    hospitals=Hospital.objects.all()
    return render(request, 'index.html',{'total_beds_available':len(beds), 'num_vaccines': len(vaccines), 'Stocks':sum, 'hospitals':hospitals})


def book(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email= request.POST.get('email')
        mobile= request.POST.get('mobile')
        date= request.POST.get('date')
        hospital= request.POST.get("hospital")
        bed= request.POST.get('flexRadioDefault1')
        vacc=request.POST.get('flexRadioDefault2')
        params={'name':name,'email':email,'mobile':mobile,'date':date,'hospital':hospital, 'bed':bed, 'vacc':vacc}
        print(params)
        if bed=='on':
            appointment=Appointment(patient_name = name, email = email, mobile = mobile, hospital_name = hospital, status = False, description="", appointmentDate = date)
            appointment.save()
            return render(request, "index.html")
        elif vacc=='on':
            book_vacc=book_vaccine(patient_name=name, email=email, mobile=mobile, hospital_name=hospital,vaccinated=False,appointmentDate = date)
            book_vacc.save()
            return render(request, 'index.html')
        else:
            return render(request, 'index.html')

    return HttpResponse("Not Working")
