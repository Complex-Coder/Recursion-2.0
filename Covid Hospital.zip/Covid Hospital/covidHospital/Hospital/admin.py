from django.contrib import admin
from .models import Doctor,Patient,Hospital,book_vaccine,vaccine_in_hosp,Bed,Vaccine,Appointment

# Register your models here.

admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Hospital)
admin.site.register(Appointment)
admin.site.register(Vaccine)
admin.site.register(Bed)
admin.site.register(vaccine_in_hosp)
admin.site.register(book_vaccine)
