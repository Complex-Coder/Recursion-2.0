from django.db import models
# yeh idhar pura datababse ka tables hai

# Create your models here.

departments = [('Cardiologist', 'Cardiologist'),
               ('Dermatologists', 'Dermatologists'),
               ('Emergency Medicine Specialists', 'Emergency Medicine Specialists'),
               ('Allergists/Immunologists', 'Allergists/Immunologists'),
               ('Anesthesiologists', 'Anesthesiologists'),
               ('Colon and Rectal Surgeons', 'Colon and Rectal Surgeons'),
               ]


class Doctor(models.Model):
    doctor_id = models.AutoField(primary_key=True)
    hospital_id=models.PositiveIntegerField(default=0)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email= models.CharField(max_length=100, default="")
    password= models.CharField(max_length=100, default="")
    profile_pic = models.ImageField(upload_to='doctors/', null=True, blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20, null=True)
    department = models.CharField(max_length=50, choices=departments, default='Practitioner')
    status = models.BooleanField(default=False)

    def __str__(self):
        return "{} ({})".format(self.first_name, self.department)


class Patient(models.Model):
    patient_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email= models.CharField(max_length=100,default="")
    password= models.CharField(max_length=100,default="")
    profile_pic = models.ImageField(upload_to='patients/', null=True, blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20, null=False)
    symptoms = models.CharField(max_length=100, null=False)
    assignedDoctorId = models.PositiveIntegerField(null=True)
    admitDate = models.DateField(auto_now=True)
    status = models.BooleanField(default=False)

    def __str__(self):
        return "{} ({})".format(self.first_name, self.symptoms)


class Hospital(models.Model):
    hospital_id = models.AutoField(primary_key=True)
    email= models.CharField(max_length=100)
    password= models.CharField(max_length=100)
    hospital_name = models.CharField(max_length=150)
    contact_number = models.PositiveIntegerField()
    address = models.CharField(max_length=40)
    status = models.BooleanField()
    city= models.CharField(max_length=200, default='')  #yeh add kardenge table mein

    def __str__(self):
        return "{} ({})".format(self.hospital_name, self.status)


class Appointment(models.Model):
    appoint_Id=models.AutoField(primary_key=True)
    patient_name=models.CharField(max_length=40,null=True, default="")
    email=models.CharField(max_length=50, default="")
    mobile=models.PositiveIntegerField(max_length=20, default=0)
    hospital_name=models.CharField(max_length=40,null=True, default="")
    description=models.TextField(max_length=500,default="")
    appointmentDate=models.DateField(auto_now=True)
    status=models.BooleanField(default=False)

    def __str__(self):
        return "Patient:{} ".format(self.patient_name)

class Bed(models.Model):
    bed_id = models.AutoField(primary_key=True)
    room_num = models.PositiveIntegerField()
    hospital_id = models.PositiveIntegerField()
    available = models.BooleanField()
    room_type = models.CharField(max_length=30)

    def __str__(self):
        return "{} ({})".format(self.bed_id, self.available)

class Vaccine(models.Model):
    vaccine_id=models.AutoField(primary_key=True)
    vaccine_name=models.CharField(max_length=100)
    for_disease= models.CharField(max_length=100)
    price= models.PositiveIntegerField()

    def __str__(self):
        return "{} ({})".format(self.vaccine_name, self.price)

class vaccine_in_hosp(models.Model):
    vaccine_id=models.PositiveIntegerField()
    hospital_id=models.PositiveIntegerField()
    available_in_stock= models.PositiveIntegerField()

    def __str__(self):
        return "{}:{} ({})".format(self.vaccine_id, self.hospital_id, self.available_in_stock)

class book_vaccine(models.Model):
    vaccination_id=models.AutoField(primary_key=True, default=1)
    patient_name=models.CharField(max_length=40,null=True, default="")
    email=models.CharField(max_length=50, default="")
    mobile=models.PositiveIntegerField(max_length=20, default=0)
    hospital_name=models.CharField(max_length=40,null=True, default="")
    appointmentDate=models.DateField(auto_now=True)
    vaccinated=models.BooleanField()
