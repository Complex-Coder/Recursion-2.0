from django.shortcuts import render
from django.http import HttpResponse
from Hospital.models import Hospital
from Hospital.models import Patient
from Hospital.models import Doctor
from Hospital.models import Appointment
from Hospital.models import Vaccine
from Hospital.models import Bed
from Hospital.models import vaccine_in_hosp
from Hospital.models import book_vaccine


# Create your views here.
def index(request):
    return render(request, 'login.html')

def signup_hosp(request):
    if request.method=='POST':
        hospital_name= request.POST.get('hospital_name')
        address= request.POST.get('address')
        contact_number= request.POST.get('contact_number')
        email= request.POST.get('email')
        password= request.POST.get('password')
        hospital_info= Hospital(hospital_name=hospital_name,address=address, contact_number=contact_number, email=email, password=password, status=False)
        hospital_info.save()
        return render(request, 'login_1.html')
    return render(request, 'login.html')

def signup_patient(request):
    if request.method=='POST':
        first_name = request.POST.get('first_name')
        last_name =  request.POST.get('last_name')
        email=  request.POST.get('email')
        password=  request.POST.get('password')
        profile_pic =  request.POST.get('profile_pic')
        address =  request.POST.get('address')
        mobile =  request.POST.get('mobile')
        symptoms =  request.POST.get('symptoms')
        assignedDoctorId =  request.POST.get('Id_doc')
        admitDate = request.POST.get('admitDate')
        patient_info= Patient(first_name=first_name, last_name=last_name, email=email, password=password, profile_pic=profile_pic, address=address,
                    mobile=mobile, symptoms=symptoms, assignedDoctorId=assignedDoctorId, admitDate=admitDate, status=False)
        patient_info.save()
        return render(request, 'login_1.html')
    return render(request, 'login.html')

def signup_doc(request):
    if request.method=='POST':
        first_name = request.POST.get('first_name')
        last_name =  request.POST.get('last_name')
        hospital_id=request.POST.get('hospital_id')
        email=  request.POST.get('email')
        password=  request.POST.get('password')
        profile_pic =  request.POST.get('profile_pic')
        address =  request.POST.get('address')
        mobile =  request.POST.get('mobile')
        department = request.POST.get('department')
        doctor_info= Doctor(first_name=first_name, last_name=last_name, hospital_id=hospital_id, email=email, password=password, profile_pic=profile_pic, address=address,
                    mobile=mobile, department=department, status=False)
        doctor_info.save()
        return render(request, 'login_1.html')
    return render(request, 'login.html')
#register done

def signin(request):
    return render(request, 'login_1.html')

def signin_hosp(request):
    if request.method=='POST':
        print("Hello")
        email=  request.POST.get('email')
        password=  request.POST.get('password')
        hospital = Hospital.objects.get(email=email) #for fetching
        print(hospital)
        params= {'hospital': hospital}
        print(hospital.password)
        if(hospital.password== password):
            print("Suucessfull")
            return render(request, 'index.html', params)
    return render(request, 'login_html')

# def signin_doc(request):
